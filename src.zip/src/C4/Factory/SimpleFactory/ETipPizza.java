package C4.Factory.SimpleFactory;

public enum ETipPizza {
	VEGETARIANA, ROMA
}
