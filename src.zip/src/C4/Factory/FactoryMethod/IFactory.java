package C4.Factory.FactoryMethod;

public interface IFactory {
	IPizza crearePizza();
}
