package C7.Adapter;

public interface IEvaluareClientFirmaA {
	void analizaClientFirmaA(int costTotalEvenimente);
}
