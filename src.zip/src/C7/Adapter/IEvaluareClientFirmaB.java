package C7.Adapter;


public interface IEvaluareClientFirmaB {
	void analizaClientFirmaB(Client client);
}
