package C5.Builder.v3;

public interface IBuilder {
	Petrecere build();
}
