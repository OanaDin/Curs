package C5.Builder.Magazin;

public interface IPodea {
	float getDuritate();
}
