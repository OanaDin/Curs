package C5.Builder.Magazin;

public interface IDecoratiuni {
	ETipMaterial getMaterial();
}
