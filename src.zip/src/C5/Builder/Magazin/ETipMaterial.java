package C5.Builder.Magazin;

public enum ETipMaterial {
	STICLA, LEMN, METAL
}
