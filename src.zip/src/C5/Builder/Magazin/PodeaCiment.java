package C5.Builder.Magazin;

public class PodeaCiment implements IPodea {

	@Override
	public float getDuritate() {
		return 10;
	}

	@Override
	public String toString() {
		return "PodeaCiment []";
	}

	
}
