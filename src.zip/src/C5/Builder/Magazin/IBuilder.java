package C5.Builder.Magazin;

public interface IBuilder {
	Magazin build();
}
