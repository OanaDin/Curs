package C9.Command;

public interface IComanda {
	void prelucreaza();
}
