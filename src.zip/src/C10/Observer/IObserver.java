package C10.Observer;

public interface IObserver {
	public void getMesaj(String mesaj);
}
