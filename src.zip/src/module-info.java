module Curs {
}