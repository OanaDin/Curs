package C6.Flyweight;

public interface IPrintare {
	void printareBon(Bon bon);
}
