package C6.Flyweight;

public enum ETipPrintare {
	TIP1, TIP2, TIP3
}
