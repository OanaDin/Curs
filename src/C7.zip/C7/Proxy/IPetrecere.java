package C7.Proxy;

public interface IPetrecere {
	public void adaugaParticipant(Client cl);
	public void afisareProgram();
}
