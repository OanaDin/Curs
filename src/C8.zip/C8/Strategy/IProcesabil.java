package C8.Strategy;

import java.util.ArrayList;

public interface IProcesabil {
	OfertaMeniu alegereMeniu(ArrayList<OfertaMeniu> listaMeniuri);
}
