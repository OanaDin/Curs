package C3.Singleton.Enum;

public enum SingletonEnum {
	INSTANCE;
	
	public static void faCeva() {
		
	}
}
