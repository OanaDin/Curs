package C9.Memento;

//clasa memento din diagrama
public class VersiuneContract {
	private String clauzeContractuale;

	public VersiuneContract(String clauzeContractuale) {
		super();
		this.clauzeContractuale = clauzeContractuale;
	}

	public String getClauzeContractuale() {
		return clauzeContractuale;
	}
	
}
