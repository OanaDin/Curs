package C9.Template;

public abstract class AEvaluareDaune {
	abstract void identificareDauna();
	abstract void evaluareInitialaDauna();
	abstract void trimitereEvaluareManager();
	
	//metoda FINAL ce implica succesiunea de pasi
	public final void proceduraEvaluareDaune(){
		identificareDauna();
		evaluareInitialaDauna();
		trimitereEvaluareManager();
	}
}
