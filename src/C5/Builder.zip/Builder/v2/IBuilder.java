package C5.Builder.v2;

public interface IBuilder {
	Petrecere build();
}
