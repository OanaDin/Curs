package C5.Builder.v1;

public interface IBuilder {
	Petrecere build();
}
