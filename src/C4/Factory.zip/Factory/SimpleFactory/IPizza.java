package C4.Factory.SimpleFactory;

public interface IPizza {
	void afisareDescriere();
}
