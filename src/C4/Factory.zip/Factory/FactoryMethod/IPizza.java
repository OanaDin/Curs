package C4.Factory.FactoryMethod;

public interface IPizza {
	void afisareDescriere();
}
