package C4.Factory.FactoryMethod;

public class PizzaRoma implements IPizza{
	
	@Override
	public void afisareDescriere() {
		System.out.println("Pizza Roma contine ....");
	}
}
