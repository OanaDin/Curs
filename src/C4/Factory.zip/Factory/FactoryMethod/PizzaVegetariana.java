package C4.Factory.FactoryMethod;

public class PizzaVegetariana implements IPizza{
	
	@Override
	public void afisareDescriere() {
		System.out.println("Pizza Vegetariana contine ....");
	}
}
